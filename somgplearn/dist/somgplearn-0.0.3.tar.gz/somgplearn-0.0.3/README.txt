This is a testing package to modify the gplearn symbolic regression
this is intended for educational use only

all the source code and copyright belong to trevor stephen and gp learn 